#!/bin/bash
#
# Developed by Rafael Corrêa Gomes
# Contact rafaelcgstz@gmail.com
#

ready(){
	echo "
		 ======================
		 	Executed!
		 "
}
