#!/bin/bash
#
# Developed by Rafael Corrêa Gomes
# Contact rafaelcgstz@gmail.com
#

update.sh(){

	sudo apt-get autoremove;
	sudo apt-get update;

}
