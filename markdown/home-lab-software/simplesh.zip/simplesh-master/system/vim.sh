#!/bin/sh
#
# Developed by Rafael Corrêa Gomes
# Contact rafaelcgstz@gmail.com
#

vim.sh(){
clear; sudo apt-get update && sudo apt-get install -y vim;
}
