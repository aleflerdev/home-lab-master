#!/bin/bash
#
# Developed by Nikhil Krishna Nair
# Contact nikhilkrishna@gmail.com
#
sudo.sh(){
	clear;
	apt-get update;
	apt install -y sudo;
}
