#!/bin/bash
#
# Developed by Nikhil Krishna Nair
# Contact nikhilkrishna@gmail.com
#

git.sh(){
    sudo apt install -y git
}