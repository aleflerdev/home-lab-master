digikam.sh(){
	sudo apt-get update;
	sudo apt-get install digikam
	clear;
	digikam;
}
