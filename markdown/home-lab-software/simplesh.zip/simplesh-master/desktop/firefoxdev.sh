#!/bin/bash
#
# Developed by Rafael Corrêa Gomes
# Contact rafaelcgstz@gmail.com
#

firefoxdev.sh(){	
    sudo add-apt-repository ppa:ubuntu-mozilla-daily/firefox-aurora &&
    sudo apt-get update &&
    sudo apt-get install firefox
}
