musique.sh(){
	sudo apt-get update;
	sudo apt-get install musique
	clear;
	musique;
}
