#!/bin/bash
#
# Developed by Nikhil Krishna Nair
# Contact nikhilkrishna@gmail.com
#
curl.sh(){
    sudo apt install -y curl wget
}