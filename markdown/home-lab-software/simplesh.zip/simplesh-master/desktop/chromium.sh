#!/bin/bash
#
# Developed by Ricardo Barantini
# Contact ricardobarantini@protonmail.com
#

chromium.sh(){
    clear;
    sudo apt-get install chromium-browser -y;
}