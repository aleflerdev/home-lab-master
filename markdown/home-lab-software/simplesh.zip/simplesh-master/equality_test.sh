#!/bin/sh

testEquality() {
	assertEquals 1 1
}

. shunit2-2.0.3/src/shell/shunit2
